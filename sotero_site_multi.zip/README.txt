
Soterô Turismo - Site (multi-page demo)

Arquivos gerados em /mnt/data/sotero_site_multi/
Abra index.html no navegador para ver o site localmente.

Imagens ilustrativas estilo marca foram salvas em /assets (SVG content stored as .png files for convenience).
Substitua por imagens finais, se quiser, mantendo os mesmos nomes de arquivo.

Para publicar online: usar GitHub Pages, Netlify ou Vercel apontando para essa pasta.
